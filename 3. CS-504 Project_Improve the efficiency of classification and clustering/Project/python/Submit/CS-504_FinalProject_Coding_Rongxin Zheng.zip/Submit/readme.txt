In my paper, I come up with some ways to debug the models, which are KNN and CF. (There are some cases these two models cannot fit.)

For question 1 and 2, I submit all the output files. Within the folder named "(K_5 K_10)", there are output files for K=5 and K=10. Within the folder named V3, there are all the output files, using v3 files as input files.

For Q1, I submit six output files. (K=3, K=5, K=10)
Using v2 file as testing data:
	ratings_predictions_knn_k_3_10.csv
	ratings_predictions_knn_k_5_10.csv
	ratings_predictions_knn_k_10_10.csv
Using v3 file as testing data:
	ratings_predictions_knn_k_3_10_V3.csv
	ratings_predictions_knn_k_5_10_V3.csv
	ratings_predictions_knn_k_10_10_V3.csv

For Q2, I submit eight output files. (05, 10, 15, 20)
Using v2 file as testing data:
	ratings_predictions_cf_05.csv
	ratings_predictions_cf_10.csv
	ratings_predictions_cf_15.csv
	ratings_predictions_cf_20.csv
Using v3 file as testing data:
	ratings_predictions_cf_05_V3.csv
	ratings_predictions_cf_10_V3.csv
	ratings_predictions_cf_15_V3.csv
	ratings_predictions_cf_20_V3.csv	